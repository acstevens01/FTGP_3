import { defineStore } from 'pinia'
import { ref, reactive } from 'vue'
import Web3 from 'web3'

import MyRouter from '@/contracts/MyRouter.json'
import MyFactory from '@/contracts/MyFactory.json'
import TokenA from '@/contracts/TokenA.json'
import TokenB from '@/contracts/TokenB.json'
import TokenC from '@/contracts/TokenC.json'
import MyPair from '@/contracts/MyPair.json'

const useAppStore = defineStore('app', () => {
    // 输入框防抖
    let timeout = null

    // 导航栏
    const tabsActive = ref('swap')

    // 钱包信息
    const address = ref('')
    const isConnect = ref(false)
    
    // 地址信息
    const myFactoryAddress = MyFactory.networks[1337].address
    const myRouterAddress = MyRouter.networks[1337].address
    const tokenAAddress = TokenA.networks[1337].address
    const tokenBAddress = TokenB.networks[1337].address
    const tokenCAddress = TokenC.networks[1337].address

    // web3/合约相关数据
    const dapp = reactive({
        loading: null,
        web3: null,
        myRouter: null,
        myFactory: null,
        tokenA: null,
        tokenB: null,
        tokenC: null,
        pairAB: null,
        pairAC: null,
        pairBC: null,
        eventSwapAB: null,
        eventSwapAC: null,
        eventSwapBC: null,
        info: {
            tokenABalance: 0,
            tokenBBalance: 0,
            tokenCBalance: 0,
            lpABBalance: 0,
            lpACBalance: 0,
            lpBCBalance: 0,
            balance: 0,
        },
        swap: {
            selected: false,
            loading: false,
            enterQuantity: false,
            addLiquidity: false,
            input1: '',
            select1: '',
            input2: '',
            select2: '',
            // 0:swapExactTokensForTokens, 1: swapTokensForExactTokens
            types: 0,
            selectList: [
                { name: 'AAA', value: tokenAAddress },
                { name: 'BBB', value: tokenBAddress },
                { name: 'CCC', value: tokenCAddress },
            ]
        }
    })

    // 钱包初始化
    const dappInit = async () => {
        try {
            // 检查环境
            if (typeof window.ethereum == 'undefined') {
                throw { code: -1, message: "Please install metamask or open the page in the dapp environment" }
            }

            // 监听钱包切换
            window.ethereum.on('accountsChanged', () => {
                window.location.reload();
            })
            // 监听网络切换
            window.ethereum.on('chainChanged', () => {
                window.location.reload()
            })

            // 检查钱包是否解锁
            window.ethereum._metamask.isUnlocked().then((res) => {
                if (!res) throw { code: -1, message: "Please unlock your wallet" }
            })
            // 检查网络
            if (window.ethereum.chainId !== 1337 && window.ethereum.networkVersion !== '1337') {
                throw { code: -1, message: "Switch to the Localhost:8575 network" }
            }
            
            // 获取当前钱包地址
            const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
            address.value = accounts[0]
            isConnect.value = true

            // 初始化web3
            dapp.web3 = new Web3(Web3.givenProvider)

            // 实例化合约
            dapp.myRouter = new dapp.web3.eth.Contract(MyRouter.abi, MyRouter.networks[1337].address)
            dapp.myFactory = new dapp.web3.eth.Contract(MyFactory.abi, MyFactory.networks[1337].address)
            dapp.tokenA = new dapp.web3.eth.Contract(TokenA.abi, TokenA.networks[1337].address)
            dapp.tokenB = new dapp.web3.eth.Contract(TokenB.abi, TokenB.networks[1337].address)
            dapp.tokenC = new dapp.web3.eth.Contract(TokenC.abi, TokenC.networks[1337].address)

            // 查询钱包余额
            await getBalance()
            // 监听各种事件
            await getEvents()

        } catch (error) {
            if (error.code == 4001) error.message = "The user refused to connect to the wallet"
            if (error.code == -32002) error.message = "Please open metamask login wallet"
            notice(`${error.message}`, false)
        }
    }

    // 连接钱包
    const walletConnect = async () => {
        dappInit()
    }

    // tabs切换事件
    const tabsChange = async () => {
        getBalance()
    }

    // 右上角提示
    const notice = (message, type) => {
        ElNotification({
            title: type ? 'Success' : 'Error',
            message,
            type: type ? 'success' : 'error',
        })
    }

    // 加载层
    const openLoading = () => {
        dapp.loading = ElLoading.service({
            lock: true,
            text: 'Loading',
            background: 'rgba(0, 0, 0, 0.3)',
        })
    }

    // 监听事件，预留功能
    const getEvents = async () => { }

    // 取消事件监听，预留功能
    const cancelEvents = async () => { }

    // 判断是否是零地址
    const isZeroAddress = (address) => {
        return address == '0x0000000000000000000000000000000000000000'
    }

    // 公共：检查select和input
    const checkSelectAndInput = () => {
        // 要求select1和select2都有数据
        if (dapp.swap.select1 != '' && dapp.swap.select2 != '') {
            dapp.swap.selected = true
        } else {
            dapp.swap.selected = false
        }

        // 要求input1和input2至少有一个有数据
        if (dapp.swap.input1 != '' || dapp.swap.input2 != '') {
            dapp.swap.enterQuantity = true
        } else {
            dapp.swap.enterQuantity = false
        }
    }

    // select事件
    const select1Change = async (val) => {
        // 如果select1与select2相同，则交换位置，清空对方
        if (val == dapp.swap.select2) {
            dapp.swap.select2 = ''
            dapp.swap.input1 = dapp.swap.input2
            dapp.swap.input2 = ''
        }

        // 检查select和input
        checkSelectAndInput()

        // 如果input2和select2都有数据，则计算input1的值
        if (dapp.swap.select2 != '' && dapp.swap.input2 != '') {
            // pair检查
            const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
            if (pair == false) return
            // 计算
            dapp.swap.input1 = await getAmountsIn(
                dapp.web3.utils.toWei(dapp.swap.input2.toString(), 'ether'),
                [dapp.swap.select1, dapp.swap.select2]
            )
            dapp.swap.loading = false
            // 使用swapTokensForExactTokens
            dapp.swap.types = 1
            console.log('调用select1Change的第3个if')
            return
        }

        // 如果input1有数据，select2有数据，则重新计算input2的值
        if (dapp.swap.select2 != '' && dapp.swap.input1 != '') {
            // pair检查
            const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
            if (pair == false) return
            // 计算
            dapp.swap.input2 = await getAmountsOut(
                dapp.web3.utils.toWei(dapp.swap.input1.toString(), 'ether'),
                [dapp.swap.select1, dapp.swap.select2]
            )
            dapp.swap.loading = false
            // 使用swapExactTokensForTokens
            dapp.swap.types = 0
            console.log('调用select1Change的第4个if')
            return
        }
    }

    // select2事件
    const select2Change = async (val) => {
        // 如果select2与select1相同，则交换位置，清空对方
        if (val == dapp.swap.select1) {
            dapp.swap.select1 = ''
            dapp.swap.input2 = dapp.swap.input1
            dapp.swap.input1 = ''
        }

        // 检查select和input
        checkSelectAndInput()

        // 如果input1和select1都有数据，则计算input2的值
        if (dapp.swap.select1 != '' && dapp.swap.input1 != '') {
            // pair检查
            const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
            if (pair == false) return
            // 计算
            dapp.swap.input2 = await getAmountsOut(
                dapp.web3.utils.toWei(dapp.swap.input1.toString(), 'ether'),
                [dapp.swap.select1, dapp.swap.select2]
            )
            dapp.swap.loading = false
            // 使用swapExactTokensForTokens
            dapp.swap.types = 0
            console.log('调用select2Change的第3个if')
            return
        }

        // 如果input2有数据，select1有数据，则重新计算input1的值
        if (dapp.swap.select1 != '' && dapp.swap.input2 != '') {
            // pair检查
            const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
            if (pair == false) return
            // 计算
            dapp.swap.input1 = await getAmountsIn(
                dapp.web3.utils.toWei(dapp.swap.input2.toString(), 'ether'),
                [dapp.swap.select1, dapp.swap.select2]
            )
            dapp.swap.loading = false
            // 使用swapTokensForExactTokens
            dapp.swap.types = 1
            console.log('调用select2Change的第4个if')
            return
        }
    }

    // input1事件
    const input1Change = async (val) => {
        // 防抖处理
        if (timeout !== null) clearTimeout(timeout)
        timeout = setTimeout(async () => {
            // 检查select和input
            checkSelectAndInput()

            // 如果input1被清空了，那么也需要清空input2
            if (dapp.swap.input1 == '') {
                dapp.swap.input2 = ''
            }

            // 如果select1，select2都有数据，则重新计算input2的值
            if (dapp.swap.select1 != '' && dapp.swap.select2 != '') {
                // pair检查
                const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
                if (pair == false) return
                // 计算
                dapp.swap.input2 = await getAmountsOut(
                    dapp.web3.utils.toWei(dapp.swap.input1.toString(), 'ether'),
                    [dapp.swap.select1, dapp.swap.select2]
                )
                dapp.swap.loading = false
                // 使用swapExactTokensForTokens
                dapp.swap.types = 0
                console.log('调用的input1事件', [dapp.swap.select1, dapp.swap.select2])
            }
        }, 1000)
    }

    // input2事件
    const input2Change = async (val) => {
        // 防抖处理
        if (timeout !== null) clearTimeout(timeout)
        timeout = setTimeout(async () => {
            // 检查select和input
            checkSelectAndInput()

            // 如果input2被清空了，那么也需要清空input1
            if (dapp.swap.input2 == '') {
                dapp.swap.input1 = ''
            }

            // 如果select1，select2都有数据，则重新计算input1的值
            if (dapp.swap.select1 != '' && dapp.swap.select2 != '') {
                // pair检查
                const pair = await checkPair(dapp.swap.select1, dapp.swap.select2)
                if (pair == false) return
                // 计算
                dapp.swap.input1 = await getAmountsIn(
                    dapp.web3.utils.toWei(dapp.swap.input2.toString(), 'ether'),
                    [dapp.swap.select1, dapp.swap.select2]
                )
                dapp.swap.loading = false
                // 使用swapTokensForExactTokens
                dapp.swap.types = 1
                console.log('调用的input2事件')
            }
        }, 1000)
    }

    // 计算固定数量的输出需要多少输入
    const getAmountsIn = async (amountOut, path) => {
        try {
            console.log("getAmountsIn", amountOut, path)

            dapp.swap.loading = true
            const res = await dapp.myRouter.methods.getAmountsIn(amountOut, path).call()
            const result = parseFloat(dapp.web3.utils.fromWei(res[0], 'ether'))
            // 计算结果太少，提示该添加流动性咯
            if (parseFloat(result) < 0.00001) {
                dapp.swap.addLiquidity = true
                return
            }
            return result
        } catch (error) {
            dapp.swap.loading = false
            // notice(`Acquisition failure: ${error.message}`, false)
            return ''
        }
    }

    // 计算固定数量的输入可以输出多少
    const getAmountsOut = async (amountIn, path) => {
        try {
            console.log("getAmountsOut", amountIn, path)

            dapp.swap.loading = true
            const res = await dapp.myRouter.methods.getAmountsOut(amountIn, path).call()
            const result = parseFloat(dapp.web3.utils.fromWei(res[1], 'ether'))
            // 计算结果低于0.00001，提示该添加流动性咯
            if (parseFloat(result) < 0.00001) {
                dapp.swap.addLiquidity = true
                return
            }
            return result
        } catch (error) {
            dapp.swap.loading = false
            // notice(`Acquisition failure: ${error.message}`, false)
            return ''
        }
    }

    // 查询余额
    const getBalance = async () => {
        // 使用多个try catch，防止某个报错影响全局
        try {
            const res = await ethereum.request({
                method: 'eth_getBalance',
                params: [address.value, 'latest'],
            })
            dapp.info.balance = parseFloat(dapp.web3.utils.fromWei(res, 'ether')).toFixed(2)
        } catch (error) { }

        try {
            const balanceA = await dapp.tokenA.methods.balanceOf(address.value).call()
            const balanceB = await dapp.tokenB.methods.balanceOf(address.value).call()
            const balanceC = await dapp.tokenC.methods.balanceOf(address.value).call()
            dapp.info.tokenABalance = parseFloat(dapp.web3.utils.fromWei(balanceA, 'ether')).toFixed(2)
            dapp.info.tokenBBalance = parseFloat(dapp.web3.utils.fromWei(balanceB, 'ether')).toFixed(2)
            dapp.info.tokenCBalance = parseFloat(dapp.web3.utils.fromWei(balanceC, 'ether')).toFixed(2)
        } catch (error) { }

        try {
            // AAA/BBB pair
            const res1 = await dapp.myFactory.methods.getPair(tokenAAddress, tokenBAddress).call()
            if (isZeroAddress(res1)) throw new Error('AAA/BBB pair does not exist')
            const pairAB = new dapp.web3.eth.Contract(MyPair.abi, res1)
            const lpABBalance = await pairAB.methods.balanceOf(address.value).call()
            dapp.info.lpABBalance = parseFloat(dapp.web3.utils.fromWei(lpABBalance, 'ether')).toFixed(2)
        } catch (error) { }

        try {
            // AAA/CCC pair
            const res2 = await dapp.myFactory.methods.getPair(tokenAAddress, tokenCAddress).call()
            if (isZeroAddress(res2)) throw new Error('AAA/CCC pair does not exist')
            const pairAC = new dapp.web3.eth.Contract(MyPair.abi, res2)
            const lpACBalance = await pairAC.methods.balanceOf(address.value).call()
            dapp.info.lpACBalance = parseFloat(dapp.web3.utils.fromWei(lpACBalance, 'ether')).toFixed(2)
        } catch (error) { }

        try {
            // BBB/CCC pair
            const res3 = await dapp.myFactory.methods.getPair(tokenBAddress, tokenCAddress).call()
            if (isZeroAddress(res3)) throw new Error('BBB/CCC pair does not exist')
            const pairBC = new dapp.web3.eth.Contract(MyPair.abi, res3)
            const lpBCBalance = await pairBC.methods.balanceOf(address.value).call()
            dapp.info.lpBCBalance = parseFloat(dapp.web3.utils.fromWei(lpBCBalance, 'ether')).toFixed(2)
        } catch (error) { }
    }

    // 添加流动性
    const addLiquidity = async (type) => {
        try {
            openLoading()

            const amount = dapp.web3.utils.toWei("100000", "ether");
            const amount2 = dapp.web3.utils.toWei("200000", "ether");

            let token1
            let token2
            switch (type) {
                case 2:
                    token1 = tokenAAddress
                    token2 = tokenCAddress
                    break
                case 3:
                    token1 = tokenBAddress
                    token2 = tokenCAddress
                    break
                default:
                    token1 = tokenAAddress
                    token2 = tokenBAddress
                    break
            }

            // 授权检查token1
            await checkAllowance(token1, amount)
            // 授权检查token2
            await checkAllowance(token2, amount2)

            await dapp.myRouter.methods.addLiquidity(
                token1,
                token2,
                amount,
                amount2,
                0,
                0,
                address.value,
                Math.floor(Date.now() / 1000) + 60 * 10
            ).send({
                from: address.value,
            })

            dapp.loading.close()
            notice(`Broadcast data success`, true)
            await getBalance()

        } catch (error) {
            dapp.loading.close()
            notice(`Operation failure: ${error.message}`, false)
        }
    }

    // 移除流动性
    const removeLiquidity = async (type) => {
        try {
            openLoading()

            let token1
            let token2
            switch (type) {
                case 2:
                    token1 = tokenAAddress
                    token2 = tokenCAddress
                    break
                case 3:
                    token1 = tokenBAddress
                    token2 = tokenCAddress
                    break
                default:
                    token1 = tokenAAddress
                    token2 = tokenBAddress
                    break
            }

            // LP授权
            const pairAddress = await dapp.myFactory.methods.getPair(token1, token2).call()
            if (isZeroAddress(pairAddress)) throw new Error('Pair does not exist')
            const pairInstance = new dapp.web3.eth.Contract(MyPair.abi, pairAddress)
            const amount = await pairInstance.methods.balanceOf(address.value).call()
            if (amount == 0) throw new Error('There is no liquidity to remove')
            await pairInstance.methods.approve(myRouterAddress, amount).send({
                from: address.value
            })

            // 移除流动性
            await dapp.myRouter.methods.removeLiquidity(
                token1,
                token2,
                amount,
                0,
                0,
                address.value,
                Math.floor(Date.now() / 1000) + 60 * 10
            ).send({
                from: address.value,
            })

            dapp.loading.close()
            notice(`Broadcast data success`, true)
            await getBalance()

        } catch (error) {
            dapp.loading.close()
            notice(`Operation failure: ${error.message}`, false)
        }
    }

    // 检查pair，调整swap按钮状态
    const checkPair = async (token1, token2) => {
        try {
            const pair =await dapp.myFactory.methods.getPair(token1, token2).call()
            if (isZeroAddress(pair)) {
                dapp.swap.addLiquidity = true
                return false
            }
            dapp.swap.addLiquidity = false
            return true
        } catch (error) {
            return false
        }
    }

    // 授权检查
    const checkAllowance = async (dst, amount) => {
        // 授权判断
        const allowanceA = parseFloat(dapp.web3.utils.fromWei(await dapp.tokenA.methods.allowance(address.value, myRouterAddress).call(), 'ether'))
        const allowanceB = parseFloat(dapp.web3.utils.fromWei(await dapp.tokenB.methods.allowance(address.value, myRouterAddress).call(), 'ether'))
        const allowanceC = parseFloat(dapp.web3.utils.fromWei(await dapp.tokenC.methods.allowance(address.value, myRouterAddress).call(), 'ether'))
        amount = dapp.web3.utils.fromWei(amount, 'ether')

        // 基于演示，授权给路由合约无限大（发行量）
        if (dst == tokenAAddress && allowanceA < amount) {
            await dapp.tokenA.methods.approve(myRouterAddress, dapp.web3.utils.toWei("100000000", 'ether')).send({
                from: address.value,
            })
        }
        if (dst == tokenBAddress && allowanceB < amount) {
            await dapp.tokenB.methods.approve(myRouterAddress, dapp.web3.utils.toWei("100000000", 'ether')).send({
                from: address.value,
            })
        }
        if (dst == tokenCAddress && allowanceC < amount) {
            await dapp.tokenC.methods.approve(myRouterAddress, dapp.web3.utils.toWei("100000000", 'ether')).send({
                from: address.value,
            })
        }
    }

    // Swap
    const swap = async () => {
        try {
            openLoading()

            // 检查输入框
            if (dapp.swap.input1 == '' || dapp.swap.input2 == '') {
                throw new Error('Please enter the correct amount')
            }

            const amountIn = dapp.web3.utils.toWei(dapp.swap.input1.toString(), 'ether');
            const amountOut = dapp.web3.utils.toWei(dapp.swap.input2.toString(), 'ether');

            // 定义参数
            const path = [dapp.swap.select1, dapp.swap.select2];
            const to = address.value;
            const deadline = Math.floor(Date.now() / 1000) + 60 * 10;

            // 授权检查
            await checkAllowance(path[0], amountIn)

            // 交换
            if (dapp.swap.types == 0) {
                await dapp.myRouter.methods.swapExactTokensForTokens(
                    amountIn,
                    // amountOutMin: 最小输出，最小为0（演示环境忽略滑点）
                    0,
                    path,
                    to,
                    deadline
                ).send({ from: to });
            } else {
                await dapp.myRouter.methods.swapTokensForExactTokens(
                    amountOut,
                    // amountInMax: 最大输入，最大为代币总发行量（演示环境忽略滑点）
                    dapp.web3.utils.toWei("100000000", 'ether'),
                    path,
                    to,
                    deadline
                ).send({ from: to });
            }

            dapp.loading.close()
            notice(`Broadcast data success`, true)
            await getBalance()

            dapp.swap.input1 = ''
            dapp.swap.input2 = ''
            dapp.swap.enterQuantity = true
            
        } catch (error) {
            dapp.loading.close()
            notice(`Operation failure: ${error.message}`, false)
        }
    }

    return {
        dapp,
        tabsActive,
        address,
        isConnect,
        myFactoryAddress,
        myRouterAddress,
        tokenAAddress,
        tokenBAddress,
        tokenCAddress,
        dappInit,
        tabsChange,
        walletConnect,
        cancelEvents,
        getBalance,
        select1Change,
        select2Change,
        input1Change,
        input2Change,
        addLiquidity,
        removeLiquidity,
        swap,
    }
}, {
    persist: {
        // 持久化tabs
        paths: ["tabsActive"]
    }
})

export default useAppStore